package com.example.splitfiles;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.InputType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int REQ_TREE = 1;

    private RadioButton rbSingle, rbGroup;
    private EditText etN;
    private TextView status;
    private Button pick;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 48, 48, 48);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("מפצל קבצים לתיקיות");
        title.setTextSize(24);
        root.addView(title);

        RadioGroup rg = new RadioGroup(this);
        rbSingle = new RadioButton(this);
        rbSingle.setText("כל קובץ בתיקייה נפרדת (שם התיקייה = שם הקובץ)");
        rbGroup = new RadioButton(this);
        rbGroup.setText("קיבוץ קבצים לפי N תווים ראשונים זהים בשם");
        rg.addView(rbSingle);
        rg.addView(rbGroup);
        rbSingle.setChecked(true);
        root.addView(rg);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView lbl = new TextView(this);
        lbl.setText("מספר תווים (N): ");
        row.addView(lbl);
        etN = new EditText(this);
        etN.setInputType(InputType.TYPE_CLASS_NUMBER);
        etN.setText("8");
        etN.setMinEms(3);
        row.addView(etN);
        for (final int n : new int[]{6, 8, 10}) {
            Button q = new Button(this);
            q.setText(String.valueOf(n));
            q.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    etN.setText(String.valueOf(n));
                    rbGroup.setChecked(true);
                }
            });
            row.addView(q);
        }
        root.addView(row);

        pick = new Button(this);
        pick.setText("בחר תיקייה והתחל");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, REQ_TREE);
            }
        });
        root.addView(pick);

        status = new TextView(this);
        status.setText("הערה: בחר את התיקייה שמכילה את הקבצים. הקבצים יועברו לתת-תיקיות בתוכה.");
        status.setPadding(0, 32, 0, 0);
        ScrollView sv = new ScrollView(this);
        sv.addView(status);
        root.addView(sv);

        setContentView(root);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_TREE || res != RESULT_OK || data == null) return;
        final Uri tree = data.getData();
        final boolean group = rbGroup.isChecked();
        int n = 8;
        try { n = Integer.parseInt(etN.getText().toString().trim()); } catch (Exception ignored) {}
        if (n < 1) n = 1;
        final int fn = n;
        pick.setEnabled(false);
        setStatus("עובד...");
        new Thread(new Runnable() {
            @Override public void run() {
                String result;
                try {
                    result = process(tree, group, fn);
                } catch (Throwable t) {
                    result = "שגיאה: " + t;
                }
                final String r = result;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        setStatus(r);
                        pick.setEnabled(true);
                    }
                });
            }
        }).start();
    }

    private void setStatus(final String s) {
        runOnUiThread(new Runnable() {
            @Override public void run() { status.setText(s); }
        });
    }

    private static class Item {
        String docId, name, mime;
    }

    private String process(Uri tree, boolean group, int n) throws Exception {
        ContentResolver cr = getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        Uri rootUri = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);

        List<Item> files = new ArrayList<>();
        Set<String> used = new HashSet<>();
        Map<String, Uri> existingDirs = new HashMap<>();

        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId);
        Cursor c = cr.query(children, new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null);
        if (c != null) {
            try {
                while (c.moveToNext()) {
                    Item it = new Item();
                    it.docId = c.getString(0);
                    it.name = c.getString(1);
                    it.mime = c.getString(2);
                    used.add(it.name);
                    if (DocumentsContract.Document.MIME_TYPE_DIR.equals(it.mime)) {
                        existingDirs.put(it.name,
                                DocumentsContract.buildDocumentUriUsingTree(tree, it.docId));
                    } else {
                        files.add(it);
                    }
                }
            } finally {
                c.close();
            }
        }

        Collections.sort(files, new java.util.Comparator<Item>() {
            @Override public int compare(Item a, Item b) { return a.name.compareToIgnoreCase(b.name); }
        });

        Map<String, Uri> groupDirs = new HashMap<>(); // group key -> dir uri
        int moved = 0, failed = 0;
        StringBuilder errs = new StringBuilder();
        int total = files.size();

        for (Item it : files) {
            try {
                String base = baseName(it.name);
                Uri dir;
                if (group) {
                    String key = base.length() > n ? base.substring(0, n) : base;
                    key = sanitize(key);
                    dir = groupDirs.get(key);
                    if (dir == null) {
                        dir = existingDirs.get(key);
                        if (dir == null) {
                            dir = DocumentsContract.createDocument(cr, rootUri,
                                    DocumentsContract.Document.MIME_TYPE_DIR, key);
                            if (dir == null) throw new Exception("יצירת תיקייה נכשלה: " + key);
                        }
                        groupDirs.put(key, dir);
                    }
                } else {
                    String dirName = sanitize(base);
                    String cand = dirName;
                    int k = 2;
                    while (used.contains(cand)) cand = dirName + "_" + (k++);
                    used.add(cand);
                    dir = DocumentsContract.createDocument(cr, rootUri,
                            DocumentsContract.Document.MIME_TYPE_DIR, cand);
                    if (dir == null) throw new Exception("יצירת תיקייה נכשלה: " + cand);
                }
                Uri src = DocumentsContract.buildDocumentUriUsingTree(tree, it.docId);
                Uri r = DocumentsContract.moveDocument(cr, src, rootUri, dir);
                if (r == null) throw new Exception("העברה נכשלה: " + it.name);
                moved++;
            } catch (Throwable t) {
                failed++;
                if (errs.length() < 1500) errs.append(it.name).append(": ").append(t.getMessage()).append("\n");
            }
            if ((moved + failed) % 10 == 0) setStatus("עובד... " + (moved + failed) + " / " + total);
        }

        String out = "סיום. הועברו " + moved + " קבצים מתוך " + total + ".";
        if (group) out += "\nנוצרו/שימשו " + groupDirs.size() + " תיקיות.";
        if (failed > 0) out += "\nנכשלו " + failed + ":\n" + errs;
        return out;
    }

    private static String baseName(String name) {
        int i = name.lastIndexOf('.');
        return (i > 0) ? name.substring(0, i) : name;
    }

    private static String sanitize(String s) {
        s = s.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (s.isEmpty()) s = "_";
        return s;
    }
}
